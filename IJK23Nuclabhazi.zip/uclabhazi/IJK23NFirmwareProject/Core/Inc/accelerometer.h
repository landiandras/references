/*
 * accelerometer.h
 *
 *  Created on: May 6, 2024
 *      Author: danny
 */

#ifndef INC_ACCELEROMETER_H_
#define INC_ACCELEROMETER_H_
#include "custom_motion_sensors.h"

CUSTOM_MOTION_SENSOR_Axes_t readaccelero();


#endif /* INC_ACCELEROMETER_H_ */
